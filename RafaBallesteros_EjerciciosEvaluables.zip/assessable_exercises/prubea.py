precio=80

cupon=20
cupon=cupon*0.01


print(precio*(1-cupon))

print(precio-(precio*cupon))